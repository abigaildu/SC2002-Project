package Admin;

public class Branch {
    private String name;
    private String daysOpen;
    private String openingHours;
    private String location;

    public Branch(String name, String daysOpen, String openingHours, String location) {
        this.name = name;
        this.daysOpen = daysOpen;
        this.openingHours = openingHours;
        this.location = location;
    }

    public String getName() {
        return name;
    }

    public String getDaysOpen() {
        return daysOpen;
    }

    public String getOpeningHours() {
        return openingHours;
    }

    public String getLocation() {
        return location;
    }

    @Override
    public String toString() {
        return "Branch{" +
                "name='" + name + '\'' +
                ", daysOpen='" + daysOpen + '\'' +
                ", openingHours='" + openingHours + '\'' +
                ", location='" + location + '\'' +
                '}';
    }
}
