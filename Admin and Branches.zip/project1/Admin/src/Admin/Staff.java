package Admin;

public class Staff {
    private int staffID;
    private String branchName;
    private char gender;
    private int age;
    private boolean branchManager;
    // Constructor
    public Staff(int staffID, String branchName, char gender, int age) {
        this.staffID = staffID;
        this.branchName = branchName;
        this.gender = gender;
        this.age = age;
    }

    // Getters and setters
    public int getStaffID() {
        return staffID;
    }

    public void setStaffID(int staffID) {
        this.staffID = staffID;
    }

    public String getBranchName() {
        return branchName;
    }

    public void setBranchName(String branchName) {
        this.branchName = branchName;
    }

    public char getGender() {
        return gender;
    }

    public void setGender(char gender) {
        this.gender = gender;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
    public boolean isBranchManager() {
        return branchManager;
    }

    public void setBranchManager(boolean branchManager) {
        this.branchManager = branchManager;
    }

    // Override toString method for displaying staff details
    @Override
    public String toString() {
        return "StaffID: " + staffID + ", Branch Name: " + branchName + ", Gender: " + gender + ", Age: " + age;
    }
}
