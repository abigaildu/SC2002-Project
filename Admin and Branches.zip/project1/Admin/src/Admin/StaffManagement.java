package Admin;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class StaffManagement {
    private List<Staff> staffList;

    public StaffManagement() {
        staffList = new ArrayList<>();
    }
    public List<Staff> getStaffInBranch(String branchName) {
        List<Staff> staffInBranch = new ArrayList<>();
        for (Staff staff : staffList) {
            if (staff.getBranchName().equalsIgnoreCase(branchName)) {
                staffInBranch.add(staff);
            }
        }
        return staffInBranch;
    }
    private boolean isStaffIDTaken(int staffID) {
        for (Staff staff : staffList) {
            if (staff.getStaffID() == staffID) {
                return true; // Staff ID is already taken
            }
        }
        return false; // Staff ID is not taken
    }

    public void addStaff(Scanner scanner) {

        System.out.println("Adding a new staff member...");
        System.out.println("Enter StaffID:");
        int staffID = scanner.nextInt();
        if (isStaffIDTaken(staffID)) {
            System.out.println("Staff ID " + staffID + " is already taken. Please choose a different ID.");
            return; // Exit the method if staff ID is already taken
        }
        scanner.nextLine(); // Consume newline character
        System.out.println("Enter Branch Assigned:");
        String branchName = scanner.nextLine();
        System.out.println("Enter Gender (M/F):");
        char gender = scanner.next().charAt(0);
        System.out.println("Enter Age:");
        int age = scanner.nextInt();
        Staff newStaff = new Staff(staffID, branchName, gender, age);
        staffList.add(newStaff);
        System.out.println("Staff member added successfully.");
    }

    public void editStaff(Scanner scanner) {
        System.out.println("Editing a staff member...");
        System.out.println("Enter the StaffID of the staff member to edit:");
        int oldStaffID = scanner.nextInt();
        scanner.nextLine(); // Consume newline character
        Staff staffToEdit = findStaffById(oldStaffID);
        if (staffToEdit != null) {
            // Display current details
            System.out.println("Current details:");
            System.out.println(staffToEdit);

            // Prompt for new details
            System.out.println("Enter new StaffID:");
            int newStaffID = scanner.nextInt();
            scanner.nextLine(); // Consume newline character

            // Check if the new StaffID is already taken
            if (isStaffIDTaken(newStaffID)) {
                System.out.println("StaffID " + newStaffID + " is already taken. Please choose a different one.");
                return;
            }

            // Update staff ID
            staffToEdit.setStaffID(newStaffID);

            // Get new details
            //System.out.println("Enter new Branch Assigned:");
            //String newBranchName = scanner.nextLine();
            System.out.println("Enter new Gender (M/F):");
            char newGender = scanner.next().charAt(0);
            System.out.println("Enter new Age:");
            int newAge = scanner.nextInt();

            // Update other staff details
            //staffToEdit.setBranchName(newBranchName);
            staffToEdit.setGender(newGender);
            staffToEdit.setAge(newAge);

            System.out.println("Staff member details updated successfully.");
        } else {
            System.out.println("Staff member with ID " + oldStaffID + " not found.");
        }
    }


    public void removeStaff(Scanner scanner) {
        System.out.println("Removing a staff member...");
        System.out.println("Enter the StaffID of the staff member to remove:");
        int staffID = scanner.nextInt();
        scanner.nextLine(); // Consume newline character
        Staff staffToRemove = findStaffById(staffID);
        if (staffToRemove != null) {
            staffList.remove(staffToRemove);
            System.out.println("Staff member removed successfully.");
        } else {
            System.out.println("Staff member with ID " + staffID + " not found.");
        }
    }

    public void displayStaffList() {
        System.out.println("Displaying staff list:");
        if (staffList.isEmpty()) {
            System.out.println("No staff members found.");
        } else {
        	for (Staff staff : staffList) {
        	String role = staff.isBranchManager() ? "Branch Manager" : "Staff";
            System.out.println("Staff ID: " + staff.getStaffID() + ", Branch: " + staff.getBranchName() + ", Role: " + role);
            }
        }
    }

    private Staff findStaffById(int staffID) {
        for (Staff staff : staffList) {
            if (staff.getStaffID() == staffID) {
                return staff;
            }
        }
        return null;
    }
     public void assignBranchManager(Scanner scanner) {
        System.out.println("Assigning a branch manager...");
        System.out.println("Enter the branch name:");
        String branchName = scanner.nextLine();

        // Find the staff members in the specified branch
        List<Staff> staffInBranch = getStaffInBranch(branchName);

        // Determine the number of managers based on the number of staff members
        int numStaff = staffInBranch.size();
        int numManagers = calculateNumManagers(numStaff);

        if (numManagers == 0) {
            System.out.println("There are no staff members in this branch.");
            return;
        }

        System.out.println("Assigning " + numManagers + " branch manager(s) to the branch.");

        // Perform the assignment of branch managers
        for (int i = 0; i < numManagers; i++) {
            // Logic to assign branch managers...
            // You may want to select the appropriate staff members from 'staffInBranch'
            // and mark them as branch managers.
        }

        System.out.println("Branch manager(s) assigned successfully.");
    }

    private int calculateNumManagers(int numStaff) {
        // Logic to determine the number of managers based on the number of staff
        // For example:
        if (numStaff <= 4) {
            return 1;
        } else if (numStaff <= 8) {
            return 2;
        } else {
            return 3;
        }
    }

    public void promoteToBranchManager(Scanner scanner) {
        System.out.println("Promoting a staff member to branch manager...");
        System.out.println("Enter the StaffID of the staff member to promote:");
        int staffID = scanner.nextInt();
        scanner.nextLine(); // Consume newline character
        Staff staffToPromote = findStaffById(staffID);
        if (staffToPromote != null) {
            // Logic to promote this staff member to branch manager
            // For example, you can set a flag in the Staff object indicating they are a branch manager
            staffToPromote.setBranchManager(true);
            System.out.println("Staff member with ID " + staffID + " promoted to branch manager.");
        } else {
            System.out.println("Staff member with ID " + staffID + " not found.");
        }
    }
    public void transferStaff(Scanner scanner) {
        System.out.println("Transferring a staff member to a new branch...");
        System.out.println("Enter the StaffID of the staff member to transfer:");
        int staffID = scanner.nextInt();
        scanner.nextLine(); // Consume newline character
        Staff staffToTransfer = findStaffById(staffID);
        if (staffToTransfer != null) {
            // Display current details
            System.out.println("Current branch assigned: " + staffToTransfer.getBranchName());

            // Prompt for new branch name
            System.out.println("Enter the name of the new branch:");
            String newBranchName = scanner.nextLine();

            // Optional: Validate if the new branch exists

            // Update branch name of the staff member
            staffToTransfer.setBranchName(newBranchName);

            System.out.println("Staff member transferred successfully to the branch: " + newBranchName);
        } else {
            System.out.println("Staff member with ID " + staffID + " not found.");
        }
    }
}
