package P1;

public class MenuItem {
	// arrays for different categories of menu items
	public enum Category {
		FOOD,
		DRINK,
		DESSERT
	}
	
	String itemName;
	String itemDesc;
	float price;
	boolean avail;
	private Category cat; // can allow user to select which menu category they want to see
	
	// constructor
	public MenuItem(String itemName, String itemDesc, float price, boolean availability, boolean avail) {
	    this.itemName = itemName;
	    this.itemDesc = itemDesc;
	    this.price = price;
	    this.avail = avail;
	}
	
	// getter and setter methods
	public String getItemName() {
	    return itemName;
	}

	public void setItemName(String itemName) {
	    this.itemName = itemName;
	}

	public String getItemDesc() {
	    return itemDesc;
	}

	public void setItemDesc(String itemDesc) {
	    this.itemDesc = itemDesc;
	}

	public float getPrice() {
	    return price;
	}

	public void setPrice(float price) {
	    this.price = price;
	}

	public boolean isAvailable() {
	    return avail;
	}

	public void setAvailability(boolean availability) {
	    this.avail = availability;
	}
	
	// string representation of menu item to display to customers
	public String toString() {
		return "Name: " + itemName + ", Description: " + itemDesc + ", Price: $" + 
				price + ", Availability: " + (avail ? "Available" : "Not Available");
	}

	public Category getCategory() {
		// TODO Auto-generated method stub
		return cat;
	}
	
	/*
	 * MenuItem burger = new MenuItem("Cheeseburger", "A delicious cheeseburger", 5.99f, true, Category.FOOD);
		MenuItem coke = new MenuItem("Coca-Cola", "Refreshing drink", 1.99f, true, Category.DRINK);
		MenuItem cake = new MenuItem("Chocolate Cake", "Dessert", 4.99f, true, Category.DESSERT);
	 */

}
