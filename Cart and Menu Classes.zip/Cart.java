package P1;
import java.util.ArrayList;
import java.util.List;

public class Cart {
    private List<MenuItem> cartItems;
    static int cartID = 1;
    private boolean dineIn;

    public Cart() {
        cartItems = new ArrayList<>();
    }

    // add menu items to the cart
    public void addMenuItem(MenuItem menuItem) {
        cartItems.add(menuItem);
    }

    // delete menu items from the cart
    public void deleteMenuItem(MenuItem menuItem) {
        cartItems.remove(menuItem);
    }

    // edit menu items in the cart
    public void editMenuItem(MenuItem oldMenuItem, MenuItem newMenuItem) {
        int index = cartItems.indexOf(oldMenuItem);
        if (index != -1) {
            cartItems.set(index, newMenuItem);
        }
    }

    // Method to calculate the total cost of items in the cart
    public float totalCost() {
        float total = 0;
        /* for-each loop iterates over each MenuItem
           object in the cartItems collection*/
        for (MenuItem menuItem : cartItems) {
            total += menuItem.getPrice();
        }
        return total;
    }

    // checkout
    public void checkout() {
        System.out.println("Checkout completed. Total cost: $" + totalCost());
        // clear cart after checkout
        clearCart();
        cartID++;
    }

    //  clear the cart
    public void clearCart() {
        cartItems.clear();
    }
    
    public int getCartID() {
    	return cartID;
    }
    
    public boolean idDineIn() {
    	return dineIn;
    }
    
    public void setDineIn(boolean dineIn) {
        this.dineIn = dineIn;
    }
}
