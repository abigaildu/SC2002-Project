package P1;
import java.util.ArrayList;
import java.util.List;

import P1.MenuItem.Category;

public class Menu {
    private List<MenuItem> menuItems;

    public Menu() {
        menuItems = new ArrayList<>();
    }
    
    // method to display entire menu
    public void displayMenu() {
        System.out.println("Menu:");
        for (MenuItem menuItem : menuItems) {
            System.out.println(menuItem);
        }
    }
    
    // method to display by selected category of menu
    public void displayItemsByCategory(Category category) {
        System.out.println(category + " Items:");
        for (MenuItem menuItem : menuItems) {
            if (menuItem.getCategory() == category) {
                System.out.println(menuItem.getItemName() + " - " + menuItem.getItemDesc() + " - $" + menuItem.getPrice());
            }
        }
    }
}
