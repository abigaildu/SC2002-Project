/**
 * 
 */
/**
 * 
 */
module console {
}