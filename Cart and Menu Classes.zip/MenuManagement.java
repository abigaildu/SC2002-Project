package P1;

import java.util.ArrayList;
import java.util.List;

public class MenuManagement {
	private List<MenuItem> menuItems;
	// list that holds MenuItem objects

	public MenuManagement() {
		this.menuItems = new ArrayList<>();
	}
	
	public void addMenuItem(MenuItem menuItem) {
		menuItems.add(menuItem);
	}

	public void removeMenuItem(MenuItem menuItem) {
        menuItems.remove(menuItem);
    }
	
	public void updateMenuItem(MenuItem menuItem, String newName, String newDesc, float newPrice, boolean newAvail) {
        if (menuItems.contains(menuItem)) {
            menuItem.setItemName(newName);
            menuItem.setItemDesc(newDesc);
            menuItem.setPrice(newPrice);
            menuItem.setAvailability(newAvail);
            System.out.println("Menu item updated successfully.");
        } else {
            System.out.println("Menu item not found.");
        }
    }
}
