package Admin;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class BranchManagement {
    private List<Branch> openBranches;

    public BranchManagement() {
        openBranches = new ArrayList<>();
    }

    public void openBranch(Scanner scanner) {
        System.out.println("Enter branch details:");
        System.out.print("Branch Name: ");
        String branchName = scanner.nextLine();
        System.out.print("Days Open (e.g., Monday-Friday): ");
        String daysOpen = scanner.nextLine();
        System.out.print("Opening Hours: ");
        String openingHours = scanner.nextLine();
        System.out.print("Location: ");
        String location = scanner.nextLine();

        Branch branch = new Branch(branchName, daysOpen, openingHours, location);
        if (!openBranches.contains(branch)) {
            openBranches.add(branch);
            System.out.println("Branch '" + branchName + "' opened successfully.");
        } else {
            System.out.println("Branch '" + branchName + "' is already open.");
        }
    }

    public void closeBranch(String branchName) {
        Branch branchToRemove = null;
        for (Branch branch : openBranches) {
            if (branch.getName().equals(branchName)) {
                branchToRemove = branch;
                break;
            }
        }
        if (branchToRemove != null) {
            openBranches.remove(branchToRemove);
            System.out.println("Branch '" + branchName + "' closed successfully.");
        } else {
            System.out.println("Branch '" + branchName + "' is not currently open.");
        }
    }

    public void displayOpenBranches() {
        System.out.println("Open Branches:");
        if (openBranches.isEmpty()) {
            System.out.println("No branches are currently open.");
        } else {
            for (Branch branch : openBranches) {
                System.out.println(branch);
            }
        }
    }
}