package Admin;

import java.util.Scanner;

public class Admin {
    public static void main(String[] args) {
        int choice;
        int age, StaffID;
        String branchname;
        char gender;

        Scanner scanner = new Scanner(System.in);
        StaffManagement staffmanagement = new StaffManagement();
        BranchManagement branchmanagement = new BranchManagement();
        PaymentMethod paymentmethod = new PaymentMethod();

        System.out.println("Choose an option:");
        System.out.println("1. Add Staff");
        System.out.println("2. Edit Staff");
        System.out.println("3. Remove Staff");
        System.out.println("4. Display Staff List");
        System.out.println("5. Assign Branch Manager");
        System.out.println("6. Promote Staff to Branch Manager");
        System.out.println("7. Transfer Staff/Manager");
        System.out.println("8. Add Payment Method");
        System.out.println("9. Remove Payment Method");
        System.out.println("10 Display Payment Methods");
        System.out.println("11. Open Branch");
        System.out.println("12. Close Branch");
        System.out.println("13. Display Open Branches");
        System.out.println("14. Exit");


        do {
            System.out.println("Enter the number of choice: ");

            choice = getInt(scanner, "Please enter a number >:(\nEnter the number of choice: ");

            switch (choice) {
            case 1:
 
                staffmanagement.addStaff(scanner);
                
                break;
            case 2:
                 staffmanagement.editStaff(scanner);
                break;
            case 3:
                staffmanagement.removeStaff(scanner);
                break;
            case 4:
                staffmanagement.displayStaffList();
                break;
            case 5:
                staffmanagement.assignBranchManager(scanner);
                break;
            case 6:
                staffmanagement.promoteToBranchManager(scanner);
                break;
            case 7:
                staffmanagement.transferStaff(scanner);
                break;
            case 8:
                //System.out.println("Enter the payment method to add:");
                //String paymentToAdd = scanner.nextLine().trim();
                //paymentmethod.addPayment(paymentToAdd);
                paymentmethod.addPayment(scanner);
                break;
            case 9:
                System.out.println("Enter the payment method to remove:");
                String paymentToRemove = scanner.nextLine().trim();
                paymentmethod.removePayment(paymentToRemove);
                //paymentmethod.removePayment(scanner);
                break;
            case 10:
            	
            	paymentmethod.displayPaymentMethods();
            	break;
            case 11:
                branchmanagement.openBranch(scanner);
                break;
            case 12:
            	System.out.println("Enter the name of the branch to close:");
                String branchNameToClose = scanner.nextLine();
                branchmanagement.closeBranch(branchNameToClose);
                break; 
            case 13:
            	branchmanagement.displayOpenBranches();
            	break;
            case 14:
                break;
            default:
            {
                System.out.println("Choose an option:");
                System.out.println("1. Add Staff");
                System.out.println("2. Edit Staff");
                System.out.println("3. Remove Staff");
                System.out.println("4. Display Staff List");
                System.out.println("5. Assign Branch Manager");
                System.out.println("6. Promote Staff to Branch Manager");
                System.out.println("7. Transfer Staff/Manager");
                System.out.println("8. Add Payment Method");
                System.out.println("9. Remove Payment Method");
                System.out.println("10. Display Payment Methods");
                System.out.println("11. Open Branch");
                System.out.println("12. Close Branch");
                System.out.println("13. Display Open Branches");
                System.out.println("14. Exit");
             }
      }
    } while (choice != 14);
 }

    public static int getInt(Scanner sc, String errorMessage) {
        while (true) {
            try {
                return sc.nextInt();
            }
            catch (Exception e) {
                System.out.println(errorMessage);
                sc.next();
            }
        }
    }
}

